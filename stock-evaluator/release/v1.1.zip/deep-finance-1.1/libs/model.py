#!/usr/bin/env python3

import tensorflow.compat.v1 as tf
import numpy as np
import os

from libs.tools import *

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '4'
tf.disable_v2_behavior()

class DeepNeuralNetwork:
    def __init__(self, name="model", layer_config=[], abs_synapse=1.0, cost='MSE', learning_rate=0.01):
        self.model_name = name
        self.layer_config = layer_config
        self.global_step = tf.Variable(0, trainable=False, name='global_step')
        self.input, self.output = tf.placeholder(tf.float32), tf.placeholder(tf.float32)
        # configure layer attributes (dimension and synapse limit)
        self.weight, self.layer = [], []
        for l in range(len(layer_config)):
            self.weight.append(tf.Variable(tf.random_uniform([layer_config[l][0], layer_config[l][1]], -abs_synapse, abs_synapse)))
        for l in range(len(layer_config)):
            if l == 0:
                self.layer.append(tf.nn.relu(tf.matmul(self.input, self.weight[l])))
            else:
                self.layer.append(tf.nn.relu(tf.matmul(self.layer[l - 1], self.weight[l])))
        # configure model/optimizer attributes
        self.cost = None
        if cost == "MSE":
            self.cost = tf.reduce_mean(tf.squared_difference(self.output, self.layer[-1]))

        self.optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)
        self.model = self.optimizer.minimize(self.cost, global_step=self.global_step)
        # load model or initialize and run session
        self.sess = tf.Session()
        self.saver = tf.train.Saver(tf.global_variables())
        ckpt = tf.train.get_checkpoint_state('./models/' + self.model_name)
        if ckpt and tf.train.checkpoint_exists(ckpt.model_checkpoint_path):
            self.saver.restore(self.sess, ckpt.model_checkpoint_path)
        else:
            self.sess.run(tf.global_variables_initializer())
    def save(self):
        self.saver.save(self.sess, './models/' + self.model_name + '/' + self.model_name + '.ckpt', global_step=self.global_step)
        layer_conf_path = "./models/" + self.model_name + "/layer-conf"
        write([self.layer_config], [layer_conf_path])
    def train(self, training_input=[], training_output=[], epoch=100):
        try:
            error = []
            for i in range(epoch + 1):
                self.sess.run(self.model, feed_dict={self.input: training_input, self.output: training_output})
                mse = self.sess.run(self.cost, feed_dict={self.input: training_input, self.output: training_output})
                if i % 10 == 0:
                    print("Epoch #{} MSE = {}" .format(i, mse))
                error.append(mse)
            self.save()
            return error
        except Exception as e:
            print("An error occurred while training model!:\n{}" .format(e))
            return False
    def predict(self, data):
        try:
            prediction = []
            prediction = self.sess.run(self.layer[-1], feed_dict={self.input: data})
            prediction = list(prediction.flatten())
            return prediction
        except Exception as e:
            print("An error occurred while running model predictions!:\n{}" .format(e))
